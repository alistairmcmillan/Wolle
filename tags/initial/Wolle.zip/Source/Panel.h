#ifndef _PANEL_H
#define _PANEL_H

#include <FilePanel.h>

class Panel : public BFilePanel {

public:

			Panel( BHandler *handler );
			
void		SendMessage(const BMessenger*, BMessage*);

private:

BHandler	*fHandler;

};

#endif